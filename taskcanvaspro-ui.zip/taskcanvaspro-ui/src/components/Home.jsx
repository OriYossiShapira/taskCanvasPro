
import './Home.css'

const Home = () => {

    return(
        <div className="home">
            <h2>TASKCANVAS Pro</h2>
            <p>Task canvas pro is a task management...</p>

        </div>
    )
}

export default Home;